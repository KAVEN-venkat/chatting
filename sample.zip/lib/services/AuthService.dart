import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class AuthService {
  Dio dio = new Dio();
  final String url = 'https://stocklift.herokuapp.com/';
  //final String url = 'http://localhost:3333/';
  getCountries() async {
    Response response = await dio.get(url + 'countries');
    return response.data;
  }

  getStates(country) async {
    Response response = await dio.get(url + 'states/' + country);
    return response.data;
  }

  getCities(country, state) async {
    Response response = await dio.get(url + 'cities/' + country + '/' + state);
    return response.data;
  }

  login(email, password) async {
    try {
      return await dio.post('https://farshore-chat.herokuapp.com/users/login',
          data: {"email": email, "password": password},
          options: Options(contentType: Headers.formUrlEncodedContentType));
    } on DioError catch (e) {
      Fluttertoast.showToast(
          msg: e.response.data['msg'],
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }

  register(userName, mobile, email, password) async {
    try {
      return await dio.post(
          'https://farshore-chat.herokuapp.com/users/register',
          data: {
            "email": email,
            "password": password,
            "user_name": userName,
            "mobile": mobile
          },
          options: Options(contentType: Headers.formUrlEncodedContentType));
    } on DioError catch (e) {
      Fluttertoast.showToast(
          msg: e.response.data['msg'],
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }
}
