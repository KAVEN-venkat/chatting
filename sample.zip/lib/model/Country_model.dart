class CountryModel {
  final String shortName;
  final String name;
  final String native;
  final String phone;
  final String continent;
  final String capital;
  final String currency;
  //final String languages;
  final String emoji;
  final String emojiU;

  CountryModel(
      {this.shortName,
      this.name,
      this.native,
      this.phone,
      this.continent,
      this.capital,
      this.currency,
      //this.languages,
      this.emoji,
      this.emojiU});

  factory CountryModel.fromJson(Map<String, dynamic> json) {
    if (json == null) return null;
    return CountryModel(
      shortName: json["shortName"],
      name: json["name"],
      native: json["native"],
      phone: json['phone'],
      continent: json['continent'],
      capital: json['capital'],
      currency: json['currency'],
      emoji: json['emoji'],
      emojiU: json['emojiU'],
    );
  }

  static List<CountryModel> fromJsonList(List list) {
    if (list == null) return null;
    return list.map((item) => CountryModel.fromJson(item)).toList();
  }

  ///this method will prevent the override of toString
  String userAsString() {
    return '#${this.shortName} ${this.name}';
  }

  ///this method will prevent the override of toString
  bool userFilterByCreationDate(String filter) {
    return this?.phone?.toString()?.contains(filter);
  }

  ///custom comparing function to check if two users are equal
  bool isEqual(CountryModel model) {
    return this?.shortName == model?.shortName;
  }

  @override
  String toString() => name;
}
/*class CountryModel {
  final String shortName;
  final String name;
  final String native;
  final String phone;
  final String continent;
  final String capital;
  final String currency;
  final String languages;
  final String emoji;
  final String emojiU;

  const CountryModel(
      {this.shortName,
      this.name,
      this.native,
      this.phone,
      this.continent,
      this.capital,
      this.currency,
      this.languages,
      this.emoji,
      this.emojiU});

  factory CountryModel.fromJson(Map<String, dynamic> json) {
    if (json == null) return null;
    return CountryModel(
        shortName: json['shortName'],
        name: json['name'],
        native: json['native'],
        phone: json['phone'],
        continent: json['continent'],
        capital: json['capital'],
        currency: json['currency'],
        languages: json['languages'],
        emoji: json['emoji'],
        emojiU: json['emojiU']);
  }
  static List<CountryModel> fromJsonList(List list) {
    if (list == null) return null;
    return list.map((item) => CountryModel.fromJson(item)).toList();
  }

  ///custom comparing function to check if two users are equal
  bool isEqual(CountryModel model) {
    return this?.name == model?.name;
  }

  @override
  String toString() => name;
}*/
