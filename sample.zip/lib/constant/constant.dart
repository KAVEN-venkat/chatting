String splash = '/AnimatedSplashScreen',
    signin = '/Signin',
    signup = '/Signup',
    home = '/Home';
