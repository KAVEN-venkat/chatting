import 'package:flutter/material.dart';

class Watchlist extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        "WATCHLIST",
        style: TextStyle(
          color: Colors.white,
        ),
      ),
    );
  }
}
