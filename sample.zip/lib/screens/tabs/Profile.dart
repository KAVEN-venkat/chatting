import 'package:flutter/material.dart';

class Profile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        "PROFILE",
        style: TextStyle(
          color: Colors.white,
        ),
      ),
    );
  }
}
