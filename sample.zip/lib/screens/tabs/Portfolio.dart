import 'package:flutter/material.dart';

class Portfolio extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        "PORTFOLIO",
        style: TextStyle(
          color: Colors.white,
        ),
      ),
    );
  }
}
