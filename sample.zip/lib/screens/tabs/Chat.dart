import 'package:flutter/material.dart';

class Chat extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        "CHAT",
        style: TextStyle(
          color: Colors.white,
        ),
      ),
    );
  }
}
