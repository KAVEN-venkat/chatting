//import 'dart:html';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:chatting/fonts/linecons_icons.dart';
import 'package:chatting/fonts/fontawesomefour_icons.dart';
import 'package:chatting/screens/tabs/news.dart';
import 'package:chatting/screens/tabs/Chat.dart';
import 'package:chatting/screens/tabs/Portfolio.dart';
import 'package:chatting/screens/tabs/Profile.dart';
import 'package:chatting/screens/tabs/Watchlist.dart';

void main() => runApp(Home());

/// This Widget is the main application widget.
class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primaryColor: new Color(0xffffffff),
        accentColor: new Color(0xff03569B),
      ),
      debugShowCheckedModeBanner: false,
      home: MyNavigationBar(),
    );
  }
}

class MyNavigationBar extends StatefulWidget {
  @override
  _State createState() => _State();
}

class _State extends State<MyNavigationBar> {
  int tabIndex = 0;
  List<Widget> listScreens;
  @override
  void initState() {
    super.initState();
    listScreens = [
      News(),
      Portfolio(),
      Watchlist(),
      Profile(),
      Chat(),
    ];
  }

  Widget appBar() {
    return AppBar(
      elevation: 0,
      automaticallyImplyLeading: false,
      title: const Text('Hi, Venkat!'),
      actions: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            CircleAvatar(
              radius: 16,
              backgroundColor: Color(0xff2A2B3F),
              child: IconButton(
                icon: Icon(
                  Icons.notifications,
                  color: Colors.white,
                  size: 16,
                ),
                onPressed: null,
              ),
            ),
            SizedBox(
              width: 10,
            ),
            CircleAvatar(
              radius: 20,
              child: ClipOval(
                child: Image(
                  width: 40.0,
                  image: Image.asset('assets/images/10.jpg').image,
                ),
              ),
            ),
            SizedBox(
              width: 19,
            )
          ],
        ),
      ],
    );
  }

  Widget searchBar() {
    return Column(
      children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            CircleAvatar(
              radius: 20,
              backgroundColor: Color(0xff00AFF3),
              child: IconButton(
                icon: Icon(
                  Icons.search,
                  color: Colors.white,
                ),
                onPressed: () {
                  print(tabIndex);
                },
              ),
            ),
            SizedBox(width: 10),
            ButtonTheme(
              minWidth: 130.0,
              height: 40,
              child: FlatButton(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18.0),
                  side: BorderSide(color: Colors.white),
                ),
                color: Colors.white,
                textColor: Color(0xff1C1C29),
                padding: EdgeInsets.all(8.0),
                onPressed: () {
                  print("Latest");
                },
                child: Text(
                  "Latest",
                  style: TextStyle(
                    fontSize: 14.0,
                  ),
                ),
              ),
            ),
            SizedBox(width: 10),
            ButtonTheme(
              minWidth: 130.0,
              height: 40.0,
              child: RaisedButton(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18.0),
                  side: BorderSide(
                    color: Color(0xff2A2B3F),
                  ),
                ),
                onPressed: () {},
                color: Color(0xff2A2B3F),
                textColor: Colors.white,
                child: Text(
                  "Top 10",
                  style: TextStyle(fontSize: 14),
                ),
              ),
            ),
          ],
        ),
        Expanded(
          child: listScreens[tabIndex],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      child: Scaffold(
        backgroundColor: Color(0xff1C1C29),
        appBar: tabIndex == 0
            ? appBar()
            : AppBar(
                title: Text("Now Profile Header"),
              ),
        body: tabIndex == 0 ? searchBar() : listScreens[tabIndex],
        //body: listScreens[tabIndex],
        bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Color(0xff2A2B3F),
          showSelectedLabels: false,
          showUnselectedLabels: false,
          type: BottomNavigationBarType.fixed,
          currentIndex: tabIndex,
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.grey,
          iconSize: 20,
          elevation: 5,
          onTap: (int index) {
            setState(() {
              tabIndex = index;
            });
          },
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(
                Linecons.doc,
              ),
              //title: Text('Articles'),
              backgroundColor: Color(0xff2A2B3F),
            ),
            BottomNavigationBarItem(
              icon: Icon(
                Fontawesomefour.briefcase,
              ),
              //title: Text('Bag'),
              backgroundColor: Color(0xff2A2B3F),
            ),
            BottomNavigationBarItem(
              icon: Icon(
                Fontawesomefour.chart_line,
              ),
              //title: Text('Chart'),
              backgroundColor: Color(0xff2A2B3F),
            ),
            BottomNavigationBarItem(
              icon: Icon(
                Fontawesomefour.user,
              ),
              //title: Text('User'),
              backgroundColor: Color(0xff2A2B3F),
            ),
            BottomNavigationBarItem(
              icon: Icon(
                Fontawesomefour.chat_empty,
              ),
              //title: Text('User'),
              backgroundColor: Color(0xff2A2B3F),
            )
          ],
        ),
      ),
      onWillPop: () => showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          backgroundColor: Color(0xff1C1C29),
          title: Text(
            'Warning',
            style: TextStyle(
              color: Colors.white,
            ),
          ),
          content: Text(
            'Do you really want to exit',
            style: TextStyle(
              color: Colors.white,
            ),
          ),
          actions: [
            FlatButton(
              child: Text(
                'Yes',
                style: TextStyle(
                  color: Colors.white,
                ),
              ),
              onPressed: () => Navigator.pop(c, true),
            ),
            FlatButton(
              child: Text(
                'No',
                style: TextStyle(
                  color: Colors.white,
                ),
              ),
              onPressed: () => Navigator.pop(c, false),
            ),
          ],
        ),
      ),
    );
  }
}
